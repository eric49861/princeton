public class HelloGoodbye{
	public static void main(String[] argv){
		System.out.println("Hello " + argv[0] + " and " + argv[1] + ".");
		System.out.println("Goodbye " + argv[1] + " and " + argv[0] + ".");		
	}

}